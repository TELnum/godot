extends Area2D

# Define the scene to switch to
var next_scene : String = "res://sceny/world.tscn"

# Signal when a body enters the area
func _on_Area2D_body_entered(body):
	if body.is_in_group("player"):  # Make sure it is the player (optional)
		get_tree().change_scene(next_scene)
