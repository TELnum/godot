extends Node

var current_scene = "world"
var transition_scene = false 

var player_exit_cliffside_posx = 0 
var player_exit_cliffside_posy = 0 
var player_start_posx = 0 
var player_start_posy = 0 

func finish_changescenes():
	if transition_scene == true:
		transition_scene = false
		if current_scene == "world":
			current_scene = "scena1"
		else:
			current_scene = "world"
		if current_scene == "scena1":
			current_scene = "game_fighter"
		else:
			current_scene = "world"
	
