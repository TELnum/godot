extends Node


const world = preload("res://sceny/world.tscn")
const scena1 = preload("res://sceny/scena1.tscn")
const game_fighter = preload("res://sceny/game_fighter.tscn")

signal on_trigger_player_spawn
var spawn_door_tag

func go_to_level(level_tag, destination_tag):
	var scene_to_load
	
	match level_tag:
		"world":
			scene_to_load = world
		"scena1":
			scene_to_load = scena1
		"game_fighter":
			scene_to_load = game_fighter
			
			
	if scene_to_load != null:
		spawn_door_tag = destination_tag
		get_tree().change_scene_to_packed(scene_to_load)
		
func trigger_player_spawn(position: Vector2, direction: String):
	on_trigger_player_spawn.emit(position, direction)
