extends Node2D



func _ready():
	pass 

	
func _on_cliff_side_transition_point_body_entered(body: Node2D) -> void:
	if body.has_method("player"):
		Global.transition_scene = true
		get_tree().change_scene_to_file("res://sceny/scena1.tscn") 
func _on_transition_body_entered(body: Node2D) -> void:
	if body.has_method("player"):
		Global.transition_scene = true
		get_tree().change_scene_to_file("res://sceny/world.tscn") 
func _on_cliff_side_transition_point_body_exited(body: Node2D) -> void:
	if body.has_method("player"):
		Global.transition_scene = false
func _on_transition_body_exited(body: Node2D) -> void:
	if body.has_method("player"):
		Global.transition_scene = false
		
