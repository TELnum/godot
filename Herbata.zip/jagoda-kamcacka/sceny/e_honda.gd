extends CharacterBody2D

@onready var animation_tree = $AnimationTree
@onready var animation_state = animation_tree.get("parameters/playback")
@onready var collision_shape = $CollisionShape2D  # Upewnij się, że masz CollisionShape2D w postaci

var is_animating = false  # Flaga blokująca spamowanie animacji
var knockback_force = 400  # Siła odrzutu
var knockback_duration = 0.2  # Czas trwania odrzutu
var is_knocked_back = false  # Sprawdzanie, czy postać jest w trakcie odrzutu
var knockback_direction = Vector2.ZERO  # Kierunek odrzutu

func _ready():
	animation_tree.active = true
	animation_state.travel("Idle")  # Ustawienie animacji Idle jako domyślnej

func _process(delta):
	# Jeśli postać jest w trakcie odrzutu, przemieszczamy ją
	if is_knocked_back:
		position += knockback_direction * knockback_force * delta
		knockback_duration -= delta

		if knockback_duration <= 0:
			is_knocked_back = false  # Zakończ odrzut po określonym czasie

	# Sprawdzamy, czy postać nie wykonuje animacji, jeśli nie, to wróć do Idle
	if not is_animating and not is_knocked_back:
		play_animation("Idle", false)

	# Sprawdzanie animacji Hundred Hand Slap po naciśnięciu przycisku
	if Input.is_action_just_pressed("ui_handslap"):
		play_animation("Hundred Hand Slap", false)

	# Sprawdzanie animacji Sumo HeadButt po naciśnięciu przycisku
	if Input.is_action_just_pressed("ui_sumohead"):
		play_animation("Sumo HeadButt", false)

func play_animation(anim_name: String, wait: bool = true):
	is_animating = true
	animation_state.travel(anim_name)

	if wait:
		# Czekamy na zakończenie animacji, jeśli wymagane
		if anim_name == "Hundred Hand Slap":
			await get_tree().create_timer(1.0).timeout  # Czas trwania animacji, dostosuj w razie potrzeby
		elif anim_name == "Sumo HeadButt":
			await get_tree().create_timer(1.6).timeout  # Zakładając, że animacja trwa około 0.8 sekundy
	
	is_animating = false

# Funkcja wywoływana, gdy postać wchodzi w kontakt z innym ciałem (Hit Collider)
func _on_body_entered(body: Node):
	if body.is_in_group("hit_colliders"):  # Sprawdzamy, czy obiekt, z którym doszło do kolizji, jest ciosami
		var direction = (position - body.position).normalized()  # Wyliczamy kierunek odrzutu
		knockback_direction = direction
		is_knocked_back = true
		knockback_duration = 0.2  # Ustawiamy czas trwania odrzutu
