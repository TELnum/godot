extends CharacterBody2D

@onready var animation_tree = $AnimationTree
@onready var animation_state = animation_tree.get("parameters/playback")

var is_animating = false  # Flaga blokująca spamowanie animacji
var punch_count = 0  # Licznik uderzeń
var last_punch_time = 0.0  # Czas ostatniego uderzenia
const COMBO_TIME = 0.6  # Maksymalny czas na wykonanie trzech uderzeń (sekundy)

var is_crouching = false  # Zmienna do kontrolowania stanu kucania

# Zmienne do trzymania czasu przytrzymywania przycisków
var shoryuken_timer = 0.0  # Czas trzymania przycisków
const SHORYUKEN_TIME = 0.5  # Czas wymagany do aktywacji Shoryuken (0.5 sekundy)

# Flaga do kontroli animacji Hadoken
var is_hadoken_active = false  # Sprawdzanie, czy Hadoken jest aktywne

# Flaga do kontroli animacji Shoryuken
var is_shoryuken_active = false  # Sprawdzanie, czy Shoryuken jest aktywne

func _ready():
	animation_tree.active = true
	animation_state.travel("Idle")  # Ustawienie animacji Idle jako domyślnej

func _process(delta):
	# Jeśli trwa animacja Hadoken lub Shoryuken, ignorujemy inne animacje
	if is_hadoken_active or is_shoryuken_active:
		return

	# Sprawdzanie komendy Hadoken (trzy szybkie uderzenia)
	if Input.is_action_just_pressed("ui_punch"):
		var current_time = Time.get_ticks_msec() / 1000.0  # Pobranie aktualnego czasu w sekundach

		if current_time - last_punch_time > COMBO_TIME:
			punch_count = 0  # Reset licznika, jeśli czas między uderzeniami jest zbyt długi
		
		punch_count += 1
		last_punch_time = current_time  # Aktualizacja czasu ostatniego uderzenia

		if punch_count >= 3:
			# Jeśli animacja Hadoken nie jest już aktywna, uruchamiamy ją
			if not is_hadoken_active:
				play_animation("Hadoken", true)  # Odtwarzamy animację Hadoken
				punch_count = 0  # Reset licznika po wykonaniu Hadokena
				is_hadoken_active = true  # Ustawienie flagi, aby zablokować inne animacje
			return  

	# Crouch + Punch = Crouched Straight Punch
	if Input.is_action_just_pressed("ui_punch") and Input.is_action_pressed("ui_crouch"):
		play_animation("Crouched Straight Punch", false)
		is_crouching = true  # Zmieniamy stan kucania, aby zapobiec powrocie do Crouch Idle

	# Tylko Crouch = Crouch Idle
	elif Input.is_action_pressed("ui_crouch"):
		if not is_animating:
			play_animation("Crouch Idle", false)
			is_crouching = true

	# Jeśli żaden z powyższych klawiszy nie jest trzymany -> Idle
	else:
		if not is_animating and is_crouching:
			play_animation("Idle", false)  # Po zakończeniu kucania, przejdź do Idle
			is_crouching = false

	# Sprawdzanie Shoryuken przez trzymanie obu przycisków przez 0.5 sekundy
	if Input.is_action_pressed("ui_punch") and Input.is_action_pressed("ui_shoryuken"):
		shoryuken_timer += delta  # Zwiększamy timer

		if shoryuken_timer >= SHORYUKEN_TIME and not is_shoryuken_active:
			play_animation("Shoryuken", true)  # Uruchamiamy animację Shoryuken po 0.5 sekundzie
			shoryuken_timer = 0.0  # Resetujemy timer po uruchomieniu animacji
			is_shoryuken_active = true  # Ustawienie flagi, aby zablokować inne animacje
	else:
		shoryuken_timer = 0.0  # Resetujemy timer, jeśli przyciski nie są trzymane

	# Sprawdzenie prostego ciosu (Straight Punch) poza kucaniem
	if Input.is_action_just_pressed("ui_punch") and not Input.is_action_pressed("ui_crouch"):
		play_animation("Straight Punch", false)

# Funkcja, która odtwarza animację, w tym przypadku pozwala na odtwarzanie animacji do końca
func play_animation(anim_name: String, wait: bool = true):
	is_animating = true
	animation_state.travel(anim_name)
	
	if wait:
		# Czekaj na zakończenie animacji
		if anim_name == "Hadoken":
			# Poczekaj na zakończenie animacji Hadoken
			await get_tree().create_timer(1.0).timeout  # Zakładając, że animacja Hadoken trwa 1 sekundę (dostosuj czas do rzeczywistego czasu trwania animacji)
		elif anim_name == "Shoryuken":
			# Poczekaj na zakończenie animacji Shoryuken
			await get_tree().create_timer(1.0).timeout  # Zakładając, że animacja Shoryuken trwa 1 sekundę (dostosuj czas do rzeczywistego czasu trwania animacji)
		elif anim_name == "Crouched Straight Punch":
			# Czekaj na zakończenie animacji Crouch Straight Punch (dostosuj czas do rzeczywistego czasu trwania animacji)
			await get_tree().create_timer(0.5).timeout

	# Resetujemy flagi po zakończeniu animacji
	if anim_name == "Hadoken":
		is_hadoken_active = false
	elif anim_name == "Shoryuken":
		is_shoryuken_active = false

	is_animating = false
